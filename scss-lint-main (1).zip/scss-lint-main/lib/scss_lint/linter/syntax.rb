module SCSSLint
  class Linter::Syntax < Linter
  end
end
