module SCSSLint
  class Linter::Encoding < Linter
  end
end
