# frozen_string_literal: true

# Defines the gem version.
module SCSSLint
  VERSION = '0.60.0'.freeze
end
